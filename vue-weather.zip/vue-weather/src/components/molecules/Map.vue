<template>
    <div id="map"></div>
</template>

<script>
// 702bc4e52a0eb90e82305143c103d8fc
import mapAxis from "@assets/mapAxis.json";

export default {
    data () {

        return {};
    },
    mounted(){
        const API_KEY = "702bc4e52a0eb90e82305143c103d8fc";

        if(window.kakao && window.kakao.map) {
            this.initMap();
        } else {
            const script = document.createElement("script");
            script.onload =()=> kakao.maps.load(this.initMap);
            script.src = `http://depi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=702bc4e52a0eb90e82305143c103d8fc`;
            document.head.appendChild(script);
        }
    },
    methods: {
        initMap(){
            const mapContainer = document.getElemnetById("map");
            const mapOption ={
                center: new kakao.maps.LatLng(36.73035, 127.967487),
                level: 8,

            };
            const map = new kakao.maps.Map(mapContainer, mapOption);
            const positions = mapAxis.map((position) => ({ 
                latlng: new kakao.maps.LatLng(...position.latlng),
                cityName: positions.cityName,
            }));
            
            //마커를 생성
            positions.forEach((item)=>{
                const marker = new kakao.maps.marker({
                    position: item.latlng,
                });
                //마커가 지도위에 표시
                marker.setMap(map);

                //클릭이벤트
                kakao.maps.event.addListener(marker,"click", ()=> {
                    const res = marker.getPosition();

                    console.log(res);
                });
            });
        },
    },
};
</script>

<style lang="scss" scoped>
    #map{
        width: 400px;
        height: 400px;

        border-radius: 16px;
        box-shadow: 0px 0px 24px 5px rgba(0,0,0,0.1);
        background-color: beige;
    }
</style>