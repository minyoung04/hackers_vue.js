<template>
  <RouterView>
  </RouterView>
</template>

<script>
export default {
  setup () {
    

    return {};
  },
};
</script>

<style>
body{
  margin: 0;
  padding: 0;
}

</style>