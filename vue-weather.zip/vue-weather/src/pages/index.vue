<template>
    <HOMEPAGE />
</template>

<script>
import HOMEPAGE from "@components/organisms/index.vue";
export default {
    components: {
    HOMEPAGE,
    },
    data () {
        

        return {};
    },
};
</script>

<style lang="scss" scoped>
@use "@assets/styles/main.scss";

.page{
    width:100vw;
    height: 100vh;

    background-color: $color-white-100;
}
</style>